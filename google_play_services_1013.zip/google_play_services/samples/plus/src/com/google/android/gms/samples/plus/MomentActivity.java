/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.android.gms.samples.plus;

import android.widget.Toast;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.plus.PlusClient;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Example of writing moments to Google+ history through PlusClient.
 */
public class MomentActivity extends FragmentActivity implements
        GooglePlayServicesClient.ConnectionCallbacks,
        GooglePlayServicesClient.OnConnectionFailedListener, AdapterView.OnItemClickListener {
    private static final String TAG = MomentActivity.class.getSimpleName();
    private static final String TAG_ERROR_DIALOG_FRAGMENT = "errorDialog";
    private static final int REQUEST_CODE_RESOLVE_FAILURE = 9000;
    private static final int REQUEST_CODE_RESOLVE_MISSING_GP = 9001;

    private ListAdapter mListAdapter;
    private ListView mMomentListView;
    private ArrayList<String> mPendingMoments;
    private PlusClient mPlusClient;
    private WriteMomentTask mAsyncTask;

    // Used to resolve connection errors with Google Play services.
    private ConnectionResult mStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.multi_moment_activity);

        mPlusClient = new PlusClient(this, this, this, SignInActivity.SCOPES);
        mListAdapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, MomentUtil.MOMENT_LIST);
        mMomentListView = (ListView) findViewById(R.id.moment_list);
        mMomentListView.setOnItemClickListener(this);
        mMomentListView.setAdapter(mListAdapter);
        mPendingMoments = new ArrayList<String>();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mPlusClient.connect();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mPlusClient.disconnect();
    }

    @Override
    public void onConnectionFailed(ConnectionResult status) {
        resetAsyncTask();

        FragmentManager fragmentManager = getSupportFragmentManager();
        if (!status.hasResolution()
                && GooglePlayServicesUtil.isUserRecoverableError(status.getErrorCode())
                && fragmentManager.findFragmentByTag(TAG_ERROR_DIALOG_FRAGMENT) == null) {
            DialogFragment fragment = new GooglePlayServicesErrorDialogFragment();
            Bundle args = new Bundle();
            args.putInt(GooglePlayServicesErrorDialogFragment.ARG_ERROR_CODE,
                    status.getErrorCode());
            args.putInt(GooglePlayServicesErrorDialogFragment.ARG_REQUEST_CODE,
                    REQUEST_CODE_RESOLVE_MISSING_GP);
            fragment.setArguments(args);
            fragment.show(fragmentManager, TAG_ERROR_DIALOG_FRAGMENT);
        } else {
            mStatus = status;
        }
    }

    @Override
    public void onConnected() {
        mMomentListView.setAdapter(mListAdapter);
        if (!mPendingMoments.isEmpty()) {
            // Write all moments that were written while the client was disconnected.
            for (String jsonMoment : mPendingMoments) {
                writeMoment(jsonMoment);
                if (Log.isLoggable(TAG, Log.INFO)) {
                    Log.i(TAG, "Writing moment");
                }
            }
        }
        mPendingMoments.clear();
    }

    @Override
    public void onDisconnected() {
        mMomentListView.setAdapter(null);
        resetAsyncTask();
    }

    @Override
    protected void onActivityResult(int requestCode, int responseCode, Intent intent) {
        switch(requestCode) {
            case REQUEST_CODE_RESOLVE_FAILURE:
                if (responseCode == RESULT_OK) {
                    mStatus = null;
                    mPlusClient.connect();
                } else {
                    Log.e(TAG, "Unable to recover from a connection failure.");
                }
                break;
            case REQUEST_CODE_RESOLVE_MISSING_GP:
                if (responseCode == RESULT_OK) {
                    mPlusClient.connect();
                } else {
                    Log.e(TAG, "Unable to install Google Play services.");
                }
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        TextView textView = (TextView) view;
        String momentType = (String) textView.getText();
        String targetUrl = MomentUtil.MOMENT_TYPES.get(momentType);

        try {
            JSONObject moment = new JSONObject();
            moment.put("type", "http://schemas.google.com/" + momentType);

            JSONObject target = new JSONObject();
            target.put("url", targetUrl);
            moment.put("target", target);

            JSONObject result = MomentUtil.getResultFor(momentType);
            if (result != null) {
                moment.put("result", result);
            }

            String jsonMoment = moment.toString();
            if (mPlusClient.isConnected()) {
                // Write the selected moment to the user's Google+ history.
                writeMoment(jsonMoment);
                if (Log.isLoggable(TAG, Log.INFO)) {
                    Log.i(TAG, "Saving to Google+ history");
                }
            } else {
                // Resolve the connection status, and write the moment once PlusClient is connected.
                mPendingMoments.add(jsonMoment);
                if (mStatus != null && mStatus.hasResolution()) {
                    try {
                        mStatus.startResolutionForResult(this, REQUEST_CODE_RESOLVE_FAILURE);
                    } catch (SendIntentException e) {
                        // The status is no longer valid.
                        mStatus = null;
                        mPlusClient.connect();
                    }
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "Unable to generate a JSON object for the moment.", e);
        }
    }

    /**
     * Resets any pending calls to Google+ API.
     */
    private void resetAsyncTask() {
        if (mAsyncTask != null) {
            mAsyncTask.cancel(false);
            mAsyncTask = null;
        }
    }

    private void writeMoment(String jsonMoment) {
        String accountName = mPlusClient.getAccountName();
        mAsyncTask = new WriteMomentTask(this, accountName, jsonMoment) {
            @Override
            protected void onUserRecoverAuthException(final UserRecoverableAuthException e) {
                // This case will be very rare since we've already authenticated by
                // connecting the PlusClient to Google Play services.
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivityForResult(e.getIntent(), REQUEST_CODE_RESOLVE_FAILURE);
                    }
                });
            }

            @Override
            protected void onPostExecute(Boolean result) {
                String displayText = (result) ? getString(R.string.plus_moment_saved)
                        : getString(R.string.plus_moment_not_saved);
                Toast.makeText(MomentActivity.this, displayText, Toast.LENGTH_LONG).show();
            }
        };

        mAsyncTask.execute();
    }
}
