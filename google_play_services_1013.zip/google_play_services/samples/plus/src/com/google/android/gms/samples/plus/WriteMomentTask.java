/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.android.gms.samples.plus;

import android.content.Context;
import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Log;
import com.google.android.gms.auth.GoogleAuthException;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.common.Scopes;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * This AsyncTask is used to write moments into the signed in user's Google+ history.
 */
public abstract class WriteMomentTask extends AsyncTask<Void, Void, Boolean> {
    private static final String TAG = WriteMomentTask.class.getSimpleName();
    private static final String WRITE_MOMENT_URL =
            "https://www.googleapis.com/plus/v1moments/people/me/moments/vault";

    private final Context mContext;
    private final String mAccountName;
    private final String mMomentJson;

    WriteMomentTask(Context context, String accountName, String momentJson) {
        this.mContext = context;
        this.mAccountName = accountName;
        this.mMomentJson = momentJson;
    }

    @Override
    protected Boolean doInBackground(Void... params) {
        // Since we've already connected a PlusClient with the
        // required scopes, we will almost certainly be able to get an
        // auth token. The only case in which this won't hold is if the user
        // has since revoked permission.
        try {
            return writeMoment(true);
        } catch (UserRecoverableAuthException e) {
            if (!isCancelled()) {
                onUserRecoverAuthException(e);
            }
        } catch (IOException e) {
            Log.e(TAG, "Transient error when requesting an OAuth 2.0 access token", e);
            return null;
        } catch (GoogleAuthException e) {
            Log.e(TAG, "Fatal error when requesting an OAuth 2.0 access token", e);
            return null;
        }

        return false;
    }

    private boolean writeMoment(boolean retry)
            throws UserRecoverableAuthException, IOException, GoogleAuthException{
        String accessToken =
                GoogleAuthUtil.getToken(mContext, mAccountName, SignInActivity.SCOPE_STRING);

        if (accessToken == null) {
            Log.e(TAG, "A valid OAuth 2.0 access token is required for writing a moment");
            return false;
        }

        AndroidHttpClient client = AndroidHttpClient.newInstance("Android");
        HttpPost request = new HttpPost(WRITE_MOMENT_URL);

        try {
            request.setEntity(new StringEntity(mMomentJson));
        } catch (UnsupportedEncodingException e) {
            Log.e(TAG, "Malformed moment JSON", e);
            return false;
        }

        request.setHeader("Content-Type", "application/json");
        request.setHeader("Authorization", "OAuth " + accessToken);
        request.setHeader("User-Agent", "Google+ Android Sample");

        try {
            HttpResponse response = client.execute(request);
            StatusLine status = response.getStatusLine();
            if (status.getStatusCode() == HttpStatus.SC_NO_CONTENT) {
                // Successfully wrote a moment to Google+ history.
                return true;
            } else {
                Log.w(TAG, "Error " + status + " when writing a moment from " +
                        request.getURI().toString());
                if (status.getStatusCode() == HttpStatus.SC_UNAUTHORIZED && retry) {
                    // Invalidate the OAuth 2.0 access token and try the request again.
                    GoogleAuthUtil.invalidateToken(mContext, accessToken);
                    return writeMoment(false);
                }
            }

        } catch (IOException e) {
            Log.e(TAG, "Errors when communicating with the Google+ API", e);
        } finally {
            client.close();
        }

        return false;
    }

    protected abstract void onUserRecoverAuthException(UserRecoverableAuthException e);
}
