The Google+ Android sample app demonstrates how you can integrate Google Play services
in your app, and use components of the Google+ platform.

To get started, visit:
https://developers.google.com/+/mobile/android
