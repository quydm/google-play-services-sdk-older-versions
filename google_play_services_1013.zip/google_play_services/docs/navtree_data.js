var NAVTREE_DATA =
[ [ "com.google.android.gms.auth", "reference/com/google/android/gms/auth/package-summary.html", [ [ "Classes", null, [ [ "GoogleAuthUtil", "reference/com/google/android/gms/auth/GoogleAuthUtil.html", null, null ] ]
, null ], [ "Exceptions", null, [ [ "GoogleAuthException", "reference/com/google/android/gms/auth/GoogleAuthException.html", null, null ], [ "GooglePlayServicesAvailabilityException", "reference/com/google/android/gms/auth/GooglePlayServicesAvailabilityException.html", null, null ], [ "UserRecoverableAuthException", "reference/com/google/android/gms/auth/UserRecoverableAuthException.html", null, null ] ]
, null ] ]
, null ], [ "com.google.android.gms.common", "reference/com/google/android/gms/common/package-summary.html", [ [ "Interfaces", null, [ [ "GooglePlayServicesClient", "reference/com/google/android/gms/common/GooglePlayServicesClient.html", null, null ], [ "GooglePlayServicesClient.ConnectionCallbacks", "reference/com/google/android/gms/common/GooglePlayServicesClient.ConnectionCallbacks.html", null, null ], [ "GooglePlayServicesClient.OnConnectionFailedListener", "reference/com/google/android/gms/common/GooglePlayServicesClient.OnConnectionFailedListener.html", null, null ] ]
, null ], [ "Classes", null, [ [ "AccountPicker", "reference/com/google/android/gms/common/AccountPicker.html", null, null ], [ "ConnectionResult", "reference/com/google/android/gms/common/ConnectionResult.html", null, null ], [ "GooglePlayServicesUtil", "reference/com/google/android/gms/common/GooglePlayServicesUtil.html", null, null ], [ "Scopes", "reference/com/google/android/gms/common/Scopes.html", null, null ] ]
, null ] ]
, null ], [ "com.google.android.gms.plus", "reference/com/google/android/gms/plus/package-summary.html", [ [ "Interfaces", null, [ [ "PlusOneButton.OnPlusOneClickListener", "reference/com/google/android/gms/plus/PlusOneButton.OnPlusOneClickListener.html", null, null ] ]
, null ], [ "Classes", null, [ [ "GooglePlusUtil", "reference/com/google/android/gms/plus/GooglePlusUtil.html", null, null ], [ "PlusClient", "reference/com/google/android/gms/plus/PlusClient.html", null, null ], [ "PlusOneButton", "reference/com/google/android/gms/plus/PlusOneButton.html", null, null ], [ "PlusSignInButton", "reference/com/google/android/gms/plus/PlusSignInButton.html", null, null ] ]
, null ] ]
, null ] ]

;

